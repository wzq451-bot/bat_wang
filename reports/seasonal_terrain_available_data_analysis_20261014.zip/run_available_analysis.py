"""Reproduce descriptive analysis; never infer individuals from device labels.

Usage: python run_available_analysis.py --input tmp_night_metrics.csv --handoff CODEX_HANDOFF_20261014.md --out outputs
No inferential test, state assignment, or use-availability model is fitted.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re

os.environ.setdefault('MPLCONFIGDIR', '/tmp/bat-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

SEASONS = ['2021夏', '2021秋']

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', type=Path, required=True)
    ap.add_argument('--handoff', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    d = pd.read_csv(args.input)
    fields = list(d.columns[3:])
    assert list(d.columns[:3]) == ['season', 'device', 'date']
    assert len(fields) == 16
    assert d.notna().all().all()
    assert np.isfinite(d[fields].to_numpy()).all()
    assert not d.duplicated(['season', 'device', 'date']).any()
    assert ((d.n > 0) & (d.n % 1 == 0)).all()
    assert np.allclose(d.net / d.path, d.straight, rtol=1e-9, atol=1e-9)
    assert np.allclose(d.path / d.n, d.mean_step, rtol=1e-9, atol=1e-9)
    dates = pd.to_datetime(d.date, format='%Y-%m-%d', errors='raise')
    assert (dates.dt.year == d.season.str[:4].astype(int)).all()
    x = d[d.season.isin(SEASONS)].copy()
    assert set(x.season) == set(SEASONS)
    assert x[['straight','turn_gt90','turn_gt135']].ge(0).all().all()
    assert x[['straight','turn_gt90','turn_gt135']].le(1).all().all()
    assert (x.turn_gt135 <= x.turn_gt90).all()
    def save(df, name):
        df.to_csv(args.out / name, index=False, encoding='utf-8-sig', float_format='%.12g')
    coverage=[]
    for season,g in x.groupby('season',sort=False):
        coverage.append(dict(season=season,rows=len(g),device_labels=g.device.nunique(),
            calendar_dates=g.date.nunique(),sum_n=int(g.n.sum()),min_n=int(g.n.min()),max_n=int(g.n.max()),
            date_start=g.date.min(),date_end=g.date.max()))
    save(pd.DataFrame(coverage),'sample_coverage.csv')
    save(x.groupby(['season','device']).agg(rows=('date','size'),dates=('date','nunique'),sum_n=('n','sum')).reset_index(),'device_label_coverage.csv')
    stats=[]
    for season,g in x.groupby('season',sort=False):
        for field in fields:
            a=g[field]
            stats.append(dict(season=season,field=field,rows=len(a),mean=a.mean(),sd=a.std(ddof=1),
                q1=a.quantile(.25),median=a.median(),q3=a.quantile(.75),minimum=a.min(),maximum=a.max()))
    stats=pd.DataFrame(stats)
    save(stats,'row_descriptive_statistics.csv')
    label=x.groupby(['season','device'])[fields].median().reset_index()
    save(label,'device_label_medians.csv')
    contrasts=[]
    for field in fields:
        a=[x.loc[x.season==s,field].median() for s in SEASONS]
        b=[label.loc[label.season==s,field].median() for s in SEASONS]
        contrasts.append(dict(field=field,summer_row_median=a[0],autumn_row_median=a[1],row_median_difference=a[1]-a[0],
            summer_label_median=b[0],autumn_label_median=b[1],label_median_difference=b[1]-b[0],
            scope='descriptive only; device labels are not verified individuals'))
    save(pd.DataFrame(contrasts),'descriptive_contrasts.csv')
    anomalies=[]
    for idx,r in d.iterrows():
        for f in ['straight','turn_gt90','turn_gt135']:
            if not 0<=r[f]<=1:
                anomalies.append(dict(csv_line=idx+2,season=r.season,device=r.device,field=f,value=r[f],issue='outside [0,1]'))
        for f in ['height_med','wind']:
            if r[f]<0:
                anomalies.append(dict(csv_line=idx+2,season=r.season,device=r.device,field=f,value=r[f],issue='negative value; definition required, not classified as error'))
    save(pd.DataFrame(anomalies),'field_review_flags.csv')
    aliases={v:f'NENU{int(re.fullmatch(r"NENU0*(\d+)(?:\.\d+)?",v).group(1)):03}' for v in x.device.unique()}
    aliases={k:v for k,v in aliases.items() if k!=v}
    save(pd.DataFrame([dict(device_label=k,candidate_id_UNCONFIRMED=v,action='not merged') for k,v in aliases.items()]),'unconfirmed_aliases.csv')
    # Parse numerical handoff tables verbatim; do not reconstruct omitted results.
    hand=args.handoff.read_text()
    state_rows=[]; estimates=[]
    for line in hand.splitlines():
        if not line.startswith('|'):continue
        cells=[c.strip() for c in line.strip('|').split('|')]
        if len(cells)==5 and cells[0] in ['Summer','Autumn'] and cells[2].isdigit():
            state_rows.append(dict(season=cells[0],state=cells[1],used_points=int(cells[2]),individuals=int(cells[3]),segments=int(cells[4])))
        elif len(cells)==5 and cells[0] in ['Summer','Autumn']:
            lo,hi=map(float,cells[4].split(' to '))
            estimates.append(dict(kind='state association',season=cells[0],state=cells[1],terrain=cells[2],estimate=float(cells[3]),lower=lo,upper=hi))
        elif len(cells)==4 and cells[0] in ['Ascent','Descent','Quasi-horizontal']:
            lo,hi=map(float,cells[3].split(' to '))
            estimates.append(dict(kind='Autumn - Summer',season='contrast',state=cells[0],terrain=cells[1],estimate=float(cells[2]),lower=lo,upper=hi))
    assert len(state_rows)==6 and len(estimates)==7
    state=pd.DataFrame(state_rows);est=pd.DataFrame(estimates)
    assert ((est.lower<est.estimate)&(est.estimate<est.upper)).all()
    state['provenance']='transcribed from handoff; not independently refitted'
    est['provenance']='selected reported signals only; not full model results; not independently refitted'
    save(state,'handoff_state_sample_sizes.csv');save(est,'handoff_selected_estimates.csv')
    compare=[]
    for s,en in zip(SEASONS,['Summer','Autumn']):
        summary_n=int(x.loc[x.season==s,'n'].sum());state_n=int(state.loc[state.season==en,'used_points'].sum())
        compare.append(dict(season=s,summary_sum_n=summary_n,handoff_state_points=state_n,numerical_difference=summary_n-state_n,
            interpretation='different eligibility/provenance may apply; no attrition rate inferred'))
    save(pd.DataFrame(compare),'sample_accounting_unreconciled.csv')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    colors=['#3274A1','#D27639']
    fig,axs=plt.subplots(2,3,figsize=(9.0,6.4),layout='constrained')
    for ax,f in zip(axs.flat,['height_med','height_iqr','rough','tpi','straight','path']):
        for j,s in enumerate(SEASONS):
            a=x.loc[x.season==s,f].to_numpy()
            offsets=np.linspace(-.13,.13,len(a))
            ax.scatter(j+offsets,a,s=23,alpha=.75,color=colors[j],edgecolors='white',linewidths=.4)
            q=np.quantile(a,[.25,.5,.75]);ax.plot([j,j],[q[0],q[2]],color='black',lw=2)
            ax.plot([j-.17,j+.17],[q[1],q[1]],color='black',lw=2)
        ax.set(xticks=[0,1],xticklabels=['Summer\n13 records','Autumn\n14 records'],title=f,ylabel='CSV value' if f!='straight' else 'net / path',xlim=(-.45,1.45))
        ax.ticklabel_format(axis='y',style='plain',useOffset=False)
        ax.grid(axis='y',alpha=.15)
    fig.suptitle('Record-level distributions (descriptive; units require verification)',fontsize=12)
    for ext in ['png','pdf']:fig.savefig(args.out/f'figure_01_record_distributions.{ext}',dpi=200)
    plt.close(fig)
    fig,axs=plt.subplots(2,1,figsize=(9,5.4),layout='constrained',gridspec_kw={'height_ratios':[4,3]})
    for ax,kind in zip(axs,['state association','Autumn - Summer']):
        subset=est[est.kind==kind].reset_index(drop=True)
        for i,r in subset.iterrows():
            ax.errorbar(r.estimate,i,xerr=[[r.estimate-r.lower],[r.upper-r.estimate]],fmt='o',color='#3274A1',capsize=3)
        labels=[f'{r.season + " | " if kind=="state association" else ""}{r.state} | {r.terrain}' for r in subset.itertuples()]
        ax.set(yticks=range(len(labels)),yticklabels=labels,title=kind,xlabel='Reported coefficient' if kind=='state association' else 'Reported coefficient difference')
        ax.invert_yaxis();ax.axvline(0,color='gray',ls='--',lw=1);ax.grid(axis='x',alpha=.15)
    fig.suptitle('Handoff transcription: selected signals only; unadjusted 95% bootstrap intervals',fontsize=10)
    for ext in ['png','pdf']:fig.savefig(args.out/f'figure_02_handoff_selected_estimates.{ext}',dpi=200)
    plt.close(fig)
    manifest=dict(scope='descriptive analysis and handoff transcription only',primary_seasons=SEASONS,
        inputs={args.input.name:hashlib.sha256(args.input.read_bytes()).hexdigest(),args.handoff.name:hashlib.sha256(args.handoff.read_bytes()).hexdigest()},
        versions={m.__name__:m.__version__ for m in [pd,np,matplotlib]},
        quantiles='pandas linear interpolation',row_weighting='equal records',label_sensitivity='median per literal device label, then equal-label median; not individual inference',
        inference_performed=False,primary_model_reproduced=False,identity_mapping_confirmed=False,
        known_limitations=['units and field definitions unconfirmed','no used-available table','no raw timestamps or coordinates','no food observations','handoff lists selected signals, not all coefficients'],
        assertions='finite values, unique keys, date-year agreement, n positive integer, two algebraic identities, primary proportion bounds, nested turn thresholds, handoff extraction')
    (args.out/'analysis_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'coverage':coverage,'summary_rows':len(stats),'handoff_estimates':len(est),'out':str(args.out)},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
