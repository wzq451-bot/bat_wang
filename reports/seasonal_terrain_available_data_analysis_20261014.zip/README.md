# 2021 夏秋现有数据分析复现包

已完成：27 条汇总记录的描述统计、记录权重与原始设备标签权重比较、字段审计、交接摘要数值转录和两张图。

未完成：HMM、使用点—可得点主模型、个体 bootstrap、食物效应检验。缺少逐点轨迹、匹配表、最新主脚本及完整结果。设备标签不等于已确认个体；指标单位未由原脚本核实。

## 复现

本包不包含上传原件。准备原始 `tmp_night_metrics.csv` 和 `CODEX_HANDOFF_20261014.md`，其 SHA256 位于 `analysis_manifest.json`。安装 pandas、numpy、matplotlib；报告构建另外需要 python-docx。已使用的数值分析版本见 manifest。

```bash
python run_available_analysis.py --input /path/to/tmp_night_metrics.csv --handoff /path/to/CODEX_HANDOFF_20261014.md --out /path/to/output
```

脚本不会改动输入。默认按原始记录等权，以线性插值计算四分位数。标签敏感性先求每个原始标签内中位数，再求标签间中位数；不会合并候选别名。点图黑线表示中位数及四分位区间，并非模型区间。

`build_available_report.py` 为报告构建源码，使用项目布局 `research_records/20261014/available_analysis` 和 `reports`；它不是脱离该布局即可运行的独立命令。报告不需要重新生成才能复现统计表与图。

## 文件解释

- `row_descriptive_statistics.csv`：全部 16 个字段的两季描述统计。
- `descriptive_contrasts.csv`：秋减夏的描述差值与标签权重检查，无检验或置信区间。
- `sample_coverage.csv`、`device_label_coverage.csv`：记录和标签覆盖。
- `device_label_medians.csv`：标签内汇总，不是个体推断结果。
- `field_review_flags.csv`：比例越界及需定义解释的负值；负值并未判为错误。
- `unconfirmed_aliases.csv`：候选别名，未执行合并。
- `handoff_selected_estimates.csv`：仅转录交接摘要中选出的 7 条信号，不是完整模型输出。
- `handoff_state_sample_sizes.csv`：交接说明的样本表，未独立复现。
- `sample_accounting_unreconciled.csv`：两份资料的计数差异，不解释成剔除率。
- `figure_01_*`：记录级描述图。
- `figure_02_*`：交接摘要转录图，不作最终论文完整系数图。

食物变化已有文献支持，但用户确认没有本项目直接食物数据。文献原文尚待接收；不将季节差异写为食物因果效应。

独立核验：标准库 statistics 核对了 32 个中位数与 32 个均值；分析脚本同时检查唯一键、有限数值、年份、整数 n、比例范围、嵌套转角比例及两项代数关系。DOCX 与 PDF 的全部正文和表格逐项核对，并完成全部页面视觉检查。
