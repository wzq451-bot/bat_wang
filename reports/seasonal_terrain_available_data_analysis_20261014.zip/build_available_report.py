"""Build the interim evidence report from computed tables, not model guesses."""
from pathlib import Path
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
A=ROOT/'available_analysis'
OUT=ROOT.parents[1]/'reports'/'seasonal_terrain_available_data_analysis_20261014.docx'
d=Document();sec=d.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=sec.bottom_margin=Cm(1.8);sec.left_margin=sec.right_margin=Cm(2)
sec.footer_distance=Cm(.8)
for s in d.styles:
    if s.type in (1,2):
        s.font.name='Noto Sans CJK SC';s._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC')
    for b in s._element.findall('.//'+qn('w:pBdr')):b.getparent().remove(b)
normal=d.styles['Normal'];normal.font.size=Pt(10.5)
normal.paragraph_format.line_spacing=1.05;normal.paragraph_format.space_after=Pt(6)
for name,size in [('Title',20),('Heading 1',15),('Heading 2',12)]:
    s=d.styles[name];s.font.size=Pt(size);s.font.color.rgb=RGBColor(0,0,0)
    s.paragraph_format.keep_with_next=True
    s.paragraph_format.space_before=Pt(9);s.paragraph_format.space_after=Pt(6)
p=sec.footer.paragraphs[0];p.alignment=2
f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');p._p.append(f)
def para(t):return d.add_paragraph(t)
def heading(t):return d.add_heading(t,level=1)
def page(t):d.add_page_break();heading(t)
def table(headers,rows,widths):
    t=d.add_table(rows=1,cols=len(headers));t.autofit=False
    for col,w in zip(t.columns,widths):col.width=Cm(w)
    for row in [headers]+list(rows):
        cells=t.rows[0].cells if row is headers else t.add_row().cells
        for c,txt,w in zip(cells,row,widths):
            c.width=Cm(w);p=c.paragraphs[0];p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3)
            r=p.add_run(str(txt));r.font.size=Pt(9)
            if row is headers:r.bold=True
        tr=cells[0]._tc.getparent();tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
    t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
    for c in t.rows[0].cells:
        shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E7EEF4');c._tc.get_or_add_tcPr().append(shade)
    borders=OxmlElement('w:tblBorders')
    for edge in ['top','bottom','left','right','insideH','insideV']:
        e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    t._tbl.tblPr.append(borders)
    d.add_paragraph().paragraph_format.space_after=Pt(1)

d.add_paragraph('南蝠夏秋地形利用阶段分析',style='Title')
para('2021 年夏秋数据核查与描述性结果  |  2026 年 10 月 14 日')
para('现有汇总记录显示夏秋在高度相关字段、地形粗糙度字段及轨迹形态上存在描述性差别。这些差别提供了后续分析线索，但不能据此判断哪个季节对地形的选择更强。整体选择问题需要将实际使用位置与可利用地形背景直接比较。')
heading('当前完成的工作')
para('本次实际计算了 27 条夏秋汇总记录的字段审计、全部 16 个数值字段的季节描述统计，以及按原始设备标签等权汇总的敏感性检查。最新交接说明中的 7 条已报告模型估计已逐项转录并绘图；这些数值并非本次重新拟合的结果。')
coverage=pd.read_csv(A/'sample_coverage.csv')
table(['项目','2021 夏季','2021 秋季'],[
    ['汇总记录数',13,14],['原始设备标签数',11,7],['覆盖日历日期数',6,5],
    ['日期范围','6 月 18 日至 7 月 2 日','11 月 24 日至 11 月 28 日'],
    ['n 字段合计',1047,1230],['每条记录 n 范围','17–167','6–219']], [5.2,6.0,6.39])
heading('决定后续解释的核查事项')
para('设备标签尚未与生物学个体逐一对应。NENU11.2、NENU11.3 等标签可能与 NENU011 有关，但本次未擅自合并。汇总行也不能自动称为独立夜晚；即使合并候选标签，同一个体同一天仍可能有多段记录。')
para('2021 数据无空值、重复的季节—设备—日期键或非有限数值；net/path=straight 与 path/n=mean_step 两个代数关系成立。负的 height_med 和 wind 值被保留并标记，不能在定义不明时判错或当作绝对高度、风速。2024 秋季不进入主比较，其两条 straight>1 的记录只记录为历史数据问题。')
para('食物差异目前只有文献依据，没有本项目的食物或食性观测。因此食物作为研究动机及讨论解释，不进入本次回归或因果检验。')

page('夏秋描述统计')
para('下表按汇总记录等权计算，格式为中位数［第 25 百分位，第 75 百分位］。字段保留原名与原始数值尺度；单位、计算方式及高度基准需结合原脚本确认。四分位区间描述记录分布，不是置信区间。')
stats=pd.read_csv(A/'row_descriptive_statistics.csv')
rows=[]
for field in stats.field.unique():
    vals=[]
    for season in ['2021夏','2021秋']:
        r=stats[(stats.field==field)&(stats.season==season)].iloc[0]
        digits=3 if field in ['straight','turn_gt90','turn_gt135'] else 2
        vals.append(f'{r["median"]:.{digits}f} [{r.q1:.{digits}f}, {r.q3:.{digits}f}]')
    rows.append([field]+vals)
table(['CSV 字段','夏季 13 条记录','秋季 14 条记录'],rows,[4.0,6.79,6.8])
para('height_med 是每条记录中已有的汇总字段；此处再次求中位数，不等于将所有原始定位点合并后的高度中位数。同理，路径类字段没有按有效跟踪时间标准化，不能直接等同于活动强度或觅食投入。')
para('mean_speed 的记录均值在夏秋分别为 20.841 与 20.767，而记录中位数分别为 20.194 与 22.596。秋季存在 n=6、mean_speed=0.333 的记录，说明仅凭一种汇总方式容易掩盖分布特征；本次没有删除该记录。')

page('记录分布与汇总方式检查')
d.add_picture(str(A/'figure_01_record_distributions.png'),width=Cm(17.3))
para('图 1  夏秋记录级分布。每个点代表 CSV 的一条记录，黑色横线为中位数、竖线为四分位区间。蓝色为夏季，橙色为秋季。记录间可能共享个体；本图未作独立样本显著性检验。')
para('秋季的 height_med、height_iqr 和 rough 字段中位数较高，tpi 和 straight 中位数较低。两季分布仍有重叠；尤其 tpi 的差异不能脱离可得地形背景解释为选择差异。')
c=pd.read_csv(A/'descriptive_contrasts.csv').set_index('field')
table(['字段','记录等权 秋减夏','标签等权 秋减夏'],[[f,f'{c.loc[f,"row_median_difference"]:.3f}',f'{c.loc[f,"label_median_difference"]:.3f}'] for f in ['height_med','rough','tpi','straight']],[5.0,6.2,6.39])
para('标签等权先求每个原始设备标签内的记录中位数，再求标签间中位数。straight 的差值由约 −0.099 缩小至 −0.017，表明效应幅度受汇总权重影响。该检查不能替代个体编号确认、个体层级模型或独立重复。')

page('交接模型结果与样本核对')
d.add_picture(str(A/'figure_02_handoff_selected_estimates.png'),width=Cm(17.3))
para('图 2  最新交接摘要中已报告信号的转录图。上半部为状态内地形关联，下半部为秋减夏的直接系数差。横线为交接记录中的未校正 95% 个体整群 bootstrap 区间。摘要仅列出部分信号，本图不是完整系数图，也不代表其余关联为零。')
para('上升态的地面高程季节差为 0.540［0.089，1.643］，TPI 季节差为 −0.322［−0.514，−0.057］；下降态地面高程季节差为 −1.290［−3.217，−0.340］。它们为状态内差异提供探索性线索，尚不能替代整体地形利用的季节比较。')
state=pd.read_csv(A/'handoff_state_sample_sizes.csv')
table(['状态','夏季 点数／个体数','秋季 点数／个体数'],[
    ['上升','214 / 6','440 / 6'],['近水平','746 / 6','637 / 7'],['下降','72 / 3','66 / 4']], [5.0,6.2,6.39])
para('交接状态点数合计为夏季 1032、秋季 1143，与汇总 CSV 的 n 合计分别相差 15 和 87。缺少逐点标识和筛选日志，不能将差额直接解释成剔除率，也不能将状态点数比例当作状态持续时间比例。下降态个体数少，且仅 NENU022 跨季重复，必须保留探索性解释。')

page('论文正文的证据组织与可用段落')
heading('引言的研究问题段落')
para('已有追踪研究表明，蝙蝠的垂直飞行与景观地形存在联系［1］；地形与夜间上升气流也已成为解释蝙蝠高空飞行的重要研究方向［2］。这些认识提示，地形可以参与蝙蝠的三维空间利用。然而，要理解这种关系的生态情境，还需要比较同一物种在不同季节中地形使用关联的方向与强度，并进一步定位季节差异所涉及的地形属性与飞行状态。')
para('本研究以南蝠夏季和秋季的追踪记录为对象，提出两个递进问题：两季是否表现出相对于可利用背景的地形使用关联，以及这些关联是否存在季节差异；若存在差异，它们体现在哪些地形属性、飞行状态组成或状态内关联中。季节性食物变化为上述比较提供生态动机，其具体内容与本物种适用范围需由对应文献界定。')
heading('已执行方法段落')
para('描述性分析限定于 2021 年夏季和秋季。保留汇总表原始记录及设备标签，不合并未经确认的别名。对数值字段检查缺失、有限性、比例范围及已知代数关系。各季节按记录等权计算中位数和四分位区间，并用原始设备标签内中位数的等权汇总检查权重敏感性。由于标签与个体关系未确定，且汇总表不含使用点—可得点配对信息，本阶段未开展地形选择推断或季节显著性检验。')
heading('描述性结果段落')
para('夏季与秋季分别包含 13 和 14 条汇总记录。记录级 height_med 中位数分别为 33.28 和 136.70，height_iqr 为 45.08 和 129.40，rough 为 50.19 和 62.98；tpi 分别为 1.11 和 −5.39。上述字段的分布差别提示需在逐点分析中进一步检查高度相关指标及地形背景。各字段的生态解释仍取决于原始定义和测量单位，当前结果不构成相对选择强度的估计。')
heading('讨论中可成立的判断')
para('地形利用的季节差异可能同时来自活动范围内可遇到的地形变化、飞行状态的时间分配变化，以及相同状态内的地形关联变化。三者需要分别检验。食物资源季节变化可以提供解释方向，但本项目没有直接食物数据，不能识别食物效应，也不能将季节系数解释为食物变化的因果作用。风场、个体组成和跟踪覆盖同样可能影响观察到的差别。')
para('这些段落用于继续发展论文。整体选择模型结果、完整状态结果、正式摘要与结论须在原始数据复核后补写，不能由当前描述统计替代。')

page('完成主分析所需输入与执行顺序')
para('首先恢复最新主脚本及其输入路径，保持原有连续段标识。逐点资料应至少能对应季节、确认后的个体编号、时间戳及其时区、经纬度及坐标系、高度及基准、原始连续段；另需定位质量和删点规则。若已有匹配表，还应提供使用点标识、匹配组标识、使用／可得标记及完整地形字段。')
para('优先接收最新主脚本和 outputs/vertical_state_terrain_primary_20261014 结果目录。由脚本确定输入依赖后，再补齐轨迹、个体映射、地形栅格或已提取的配对表，可减少无关历史文件传输。保留文件夹相对结构，并提供单位、TPI 邻域、粗糙度公式、标准化参数及 95% kernel UD 设定。')
heading('恢复后按此顺序实施')
para('1 复现最新状态分析，核对逐点去向、各状态样本量、完整系数表、bootstrap 成功次数与失败原因。')
para('2 按整体研究问题建立一致的样本纳入标准，核查两季可得地形范围和共同支持；在同一尺度上估计季节特异地形关联及直接季节差异。整体样本不自动受限于高置信度状态点。')
para('3 区分时间加权的状态组成与状态内关联。跨季重复个体在重采样时保持联合身份；检查少数个体影响、可得背景定义、状态阈值和多重比较对结论的影响。具体模型实现由原脚本和数据结构决定。')
para('4 以完整结果安排主图和正文：整体季节比较为主结果，地形属性及状态分析定位差异；食物文献进入引言和讨论。若整体差异不明确，如实报告估计精度与证据范围。')
heading('来源与复现')
para('汇总数据为 tmp_night_metrics.csv；已有模型数值来源于 CODEX_HANDOFF_20261014.md。复现包提供分析脚本、计算表、图件及输入 SHA256，不包含原始轨迹或上传原件。审计与描述统计已实际执行；HMM、条件逻辑模型和个体 bootstrap 尚未在本环境重新执行。')
para('［1］Roeleke M, Bumrungsri S, Voigt CC. 2018. Bats probe the aerosphere during landscape-guided altitudinal flights. Mammal Review 48:7–11. DOI: 10.1111/mam.12109。依据上传的原文提取文本。')
para('［2］O’Mara MT et al. 2021. Bats use topography and nocturnal updrafts to fly high and fast. Current Biology。当前已读上传的补充材料；正文中的收益论证仍需核对。食物季节变化的具体文献尚待接收，未补造引用。')
d.core_properties.title='南蝠夏秋地形利用阶段分析';d.core_properties.author=''
d.save(OUT);print(OUT)
